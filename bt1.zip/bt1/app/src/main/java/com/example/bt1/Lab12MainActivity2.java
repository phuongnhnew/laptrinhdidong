package com.example.bt1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Lab12MainActivity2 extends AppCompatActivity {

    TextView tv2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lab12_main2);
        tv2= findViewById(R.id.b12Tv1);
        String t= "Cap nhat text vao activity 2";
        tv2.setText(t);

    }
}