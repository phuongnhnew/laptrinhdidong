package com.example.bt1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    //b1 keo tha
    //anh xa giao dien vao code java
    TextView tv1;//khai bao
    Button btn1;//khai bao

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tv1 = findViewById(R.id.b1Tv1);//anh xa textview vao java
        btn1 = findViewById(R.id.b1Btn1);//anh xa button vao java
        //xu ly su kien
        /*
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //hien thi thong tin
                String hoten = "Nguyen Van A";
                String masv = "1234";
                String ht_masv = hoten + "; " + masv;
                Toast.makeText(getApplicationContext(),ht_masv,Toast.LENGTH_LONG).show();
                //dua du lieu vao textview
                tv1.setText(ht_masv);
            }*/

        }

    public void xlsk1(View view) {
        String hoten = "Nguyen Van An";
        String masv = "123456";
        String ht_masv = hoten + "; " + masv;
        Toast.makeText(getApplicationContext(),ht_masv,Toast.LENGTH_LONG).show();
        //dua du lieu vao textview
        tv1.setText(ht_masv);
    }
}